import 'package:flutter/material.dart';
import 'dart:async';

void main() {
  runApp(TimerApp());
}

class TimerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Timer App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: TimerHomePage(),
    );
  }
}

class TimerHomePage extends StatefulWidget {
  @override
  _TimerHomePageState createState() => _TimerHomePageState();
}

class _TimerHomePageState extends State<TimerHomePage> {
  int totalTimeInSeconds = 0;
  int currentSeconds = 0;
  Timer? timer;
  TextEditingController _controller = TextEditingController();

  void startTimer() {
    timer?.cancel();
    timer = Timer.periodic(Duration(seconds: 1), (Timer timer) {
      if (currentSeconds == 0) {
        timer.cancel();
      } else {
        setState(() {
          currentSeconds--;
        });
      }
    });
  }

  void stopTimer() {
    timer?.cancel();
  }

  void resetTimer() {
    timer?.cancel();
    setState(() {
      currentSeconds = totalTimeInSeconds;
    });
  }

  void setTime(int minutes) {
    setState(() {
      totalTimeInSeconds = minutes * 60;
      currentSeconds = totalTimeInSeconds;
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Timer App'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(height: 20),
            TimerDisplay(currentSeconds: currentSeconds),
            SizedBox(height: 20),
            TimerInputField(controller: _controller, onSubmitted: (value) {
              setTime(int.tryParse(value) ?? 0);
            }),
            SizedBox(height: 20),
            TimerControlButtons(
              onStart: startTimer,
              onStop: stopTimer,
              onReset: resetTimer,
            ),
          ],
        ),
      ),
    );
  }
}

class TimerDisplay extends StatelessWidget {
  final int currentSeconds;

  TimerDisplay({required this.currentSeconds});

  @override
  Widget build(BuildContext context) {
    int minutes = currentSeconds ~/ 60;
    int seconds = currentSeconds % 60;
    return Text(
      '$minutes:${seconds.toString().padLeft(2, '0')}',
      style: TextStyle(fontSize: 48),
    );
  }
}

class TimerInputField extends StatelessWidget {
  final TextEditingController controller;
  final ValueChanged<String> onSubmitted;

  TimerInputField({required this.controller, required this.onSubmitted});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 50.0),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          border: OutlineInputBorder(),
          labelText: 'Enter minutes',
        ),
        onSubmitted: onSubmitted,
      ),
    );
  }
}

class TimerControlButtons extends StatelessWidget {
  final VoidCallback onStart;
  final VoidCallback onStop;
  final VoidCallback onReset;

  TimerControlButtons({required this.onStart, required this.onStop, required this.onReset});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        ElevatedButton(
          onPressed: onStart,
          child: Text('Start'),
        ),
        SizedBox(width: 20),
        ElevatedButton(
          onPressed: onStop,
          child: Text('Stop'),
        ),
        SizedBox(width: 20),
        ElevatedButton(
          onPressed: onReset,
          child: Text('Reset'),
        ),
      ],
    );
  }
}
